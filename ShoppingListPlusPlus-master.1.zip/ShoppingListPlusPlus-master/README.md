ShoppingListPlusPlus
========

ShoppingListPlusPlus is the companion Android app for the Udacity course Firebase Essentials :Build a Collaborative Shopping List App. 

The course covers everything you need to know to incorporate the [Firebase](https://www.firebase.com) into an Android App.
